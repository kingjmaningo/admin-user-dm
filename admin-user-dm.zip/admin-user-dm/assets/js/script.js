jQuery(document).ready(function($){
	$('.adm-action').click(function(e) {
		e.preventDefault();
		var msg_action = $(this).attr('data');
		var dm_id = $(this).parent().attr('dm-id');
		var hide_class = $(this).addClass('hide');
		$.ajax({
			url : aud_ajax_object.ajaxurl,
			type : 'post',
			data : {
				action : 'aud_message_action',
				msg_action : msg_action,
				dm_id : dm_id
			},
			beforeSend: function() {
          		$("." + dm_id + "-wrap .aud-loader").css('display', 'inline-block');

        	},
			success: function(response){
				if (msg_action == 'adm-delete') {
					$(".dm-" + dm_id).hide();
				}
				$('.hide').hide();
				$(".aud-loader").hide();
			}
		});
	});
});