jQuery(document).ready(function($){
    $('.aus_radio_option').click(function(){
        var inputValue = $(this).attr("value");
        var targetBox = $(".show_" + inputValue);
        $(".aud_dm_opt").not(targetBox).hide();
        $(".arc_single").not(targetBox).attr("checked", false);
        $(".aud-user-list").not(targetBox).val("");
        $(targetBox).show();
    });
    $('#aud-send-dm-btn').click(function(e){
    	e.preventDefault();
    	var aud_to = $('.aus_radio_option:checked').val();
    	var aud_dmn_message = $('#aud_admin_dm_message').val();
    	var aud_single_user = $('.aud-user-list').val();
    	var aud_roles = [];
		$.each($(".arc_single:checked"), function(){            
		    aud_roles.push($(this).val());
		});
		$.ajax({
			url : aud_ajax_object.ajaxurl,
			type : 'post',
			data : {
				action : 'aud_send_dm',
				aud_to  : aud_to,
				aud_dmn_message : aud_dmn_message,
				aud_single_user : aud_single_user,
				aud_roles : aud_roles
			},
			beforeSend: function() {
				$('.aud-loader').show();
			},
			success: function(response){
				$('.aud-loader').hide();
				$('#aud_admin_dm_message').val('');
				$('.aud-status').html("Sent!");
			}
		});
    });
});