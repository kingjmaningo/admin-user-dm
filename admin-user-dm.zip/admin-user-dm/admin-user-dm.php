<?php
/*
  Plugin Name: Admin-User DM
  Plugin URI: #
  Description: Send private messages to users from dashboard to their messagesing page in the frontend.
  Version: 1.0
  Author: Kingj Maningo
  Author URI: http://facebook.com/jman0709
  Text Domain: admin-user-dm
*/
 if ( ! defined( 'ABSPATH' ) ){ exit; }
define( 'ADMIN_USER_DM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'ADMIN_USER_DM_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'ADMIN_USER_DM_TEXTDOMAIN', 'book-post-lignt' );
define( 'ADMIN_USER_DM_VERSION', '1.0.0' );
define( 'ADMIN_USER_DM_DB_VERSION', '1.0.0' );
define( 'ADMIN_USER_DM_HOME_URL', home_url() );
require_once( ADMIN_USER_DM_PLUGIN_PATH . '/classes/class-core.php' );

// add_filter('use_block_editor_for_post', '__return_false', 10);
// add_filter('use_block_editor_for_post_type', '__return_false', 10);

register_activation_hook(
		__FILE__ ,'add_my_custom_page'
		);
function add_my_custom_page() {
	$my_post = array(
	  'post_title'		=> 'Messages',
	  'post_content'	=> '[aud-display-dm-page]',
	  'post_status'		=> 'publish',
	  'post_author'		=> 1,
	  'post_type'     	=> 'page',
	  'guid'			=> 'aud-inbox'
	);
	wp_insert_post( $my_post );
}
function send_dm($aud_user_id,$aud_dmn_message) {
	$aud_time = date("d-m-Y H:i A");
	$current_aud = get_user_meta($aud_user_id, 'user_admin_dms', true ) ? : array();
	$msg_id = $aud_user_id.'000';
	$highest_mid = max(array_column($current_aud, 'message_id')) ? : $msg_id;
	$new_mid = $highest_mid + 1;
	$update_user_dm = array_filter( 
							array_merge( 
								array( 
									array( 
										'aud_user_id' 	=> $aud_user_id,
										'admin_message' => $aud_dmn_message,
										'time' 			=> $aud_time,
										'status'		=> 'unread',
										'message_id' 	=> $new_mid,
									) 
								), 
								(array) $current_aud
							)
						);
	update_user_meta($aud_user_id, 'user_admin_dms', $update_user_dm);
}