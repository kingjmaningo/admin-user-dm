<?php 
class ADMIN_USER_DM_CLASS {
	function __construct(){
		//add_action( 'wp_enqueue_scripts', array( $this, 'aud_enqueue_scripts') );
		add_action( 'wp_enqueue_scripts', array( $this, 'aud_enqueue_scripts') );
		add_action( 'admin_enqueue_scripts', array( $this, 'aud_enqueue_admin_scripts') );
		add_action('admin_menu', array( $this ,'aud_register_settings_page'));
		add_action( 'wp_ajax_aud_send_dm', array( $this ,'aud_send_dm' ));
		add_action('wp_ajax_nopriv_aud_send_dm', array( $this ,'aud_send_dm'));
		add_action('init',array( $this ,'update_aud_message_title'));
		add_shortcode( 'aud-display-dm-page',array( $this ,'aud_display_dm_page'));
		add_action( 'wp_ajax_aud_message_action',array( $this ,'aud_message_action'));
		add_action('wp_ajax_nopriv_aud_message_action',array( $this ,'aud_message_action'));
	}
	function aud_enqueue_scripts() {
		// Front-end styles
		wp_register_style( 'aud-style', ADMIN_USER_DM_PLUGIN_URL . 'assets/css/style.css', ADMIN_USER_DM_DB_VERSION);
		wp_enqueue_style( 'aud-style' );
		// Front-end ajax
		wp_enqueue_script( 'jquery' );
		wp_localize_script( 'jquery', 'aud_ajax_object',
				array( 
					'ajaxurl' => admin_url( 'admin-ajax.php' )
				) 
			); ; 
		// Front-end scripts
		wp_register_script( 'aud-script', ADMIN_USER_DM_PLUGIN_URL . 'assets/js/script.js', array( 'jquery' ), ADMIN_USER_DM_DB_VERSION, true );
		wp_enqueue_script( 'aud-script' ); 
	}
	function aud_enqueue_admin_scripts() {
		// admin stylea
		wp_register_style( 'aud-style', ADMIN_USER_DM_PLUGIN_URL . 'admin/assets/css/admin-style.css', ADMIN_USER_DM_DB_VERSION);
		wp_enqueue_style( 'aud-style' );
		// admin scripts
		wp_enqueue_script( 'aud-admin-script', ADMIN_USER_DM_PLUGIN_URL . 'admin/assets/js/admin-scripts.js', array( 'jquery' ), ADMIN_USER_DM_DB_VERSION, true );
		// admin ajax
		wp_enqueue_script( 'jquery' );
		wp_localize_script( 'jquery', 'aud_ajax_object',
				array( 
					'ajaxurl' => admin_url( 'admin-ajax.php' )
				) 
			); 
	}
	function aud_message_action() {
		$msga_data = $_REQUEST['msg_action'];
		$dm_id = $_REQUEST['dm_id'];
		$current_adm = get_user_meta(get_current_user_id(), 'user_admin_dms', true ); 
		$dm_id_array = array();

		if ($msga_data == 'adm-read') :
			foreach ($current_adm as $key => $value) {
				if($value['message_id'] == $dm_id){
					$current_adm[$key]['status'] = 'read';
				}
			}
			update_user_meta(get_current_user_id(), 'user_admin_dms', $current_adm );
		else :
			$selected_dm = array_search($dm_id, array_column($current_adm, 'message_id'));
			unset($current_adm[$selected_dm]);
			$current_adm_new = array_values($current_adm);
	        update_user_meta( get_current_user_id(), 'user_admin_dms', $current_adm_new );
		endif;
		
		die();
	}
	// Add a menu on the settings page
	function aud_register_settings_page() {
  		add_users_page('Send User DM', 'User DMs', 'read', 'user-dms-page', array(
                $this,
                'aud_dm_page'
            ));
	}
	function aud_dm_page() { 
		global $wp_roles;
		$aud_roles = $wp_roles->get_names();?>
		<div class="wrap">
			<h1>Send Direct Messages</h1>
			<table class="form-table" role="presentation">
				<tbody>
					<tr>
						<th scope="row">Send Messages To</th>
						<td class="aud_admin_main_nav">
							<fieldset><legend class="screen-reader-text"><span>Date Format</span></legend>
								<input class="aus_radio_option" type="radio" id="aud_radio_all" name="dm_users" value="dm_all_users" checked>
								<label for="dm_all_users">All users</label><br>
								<input class="aus_radio_option" type="radio" id="aud_radio_role" name="dm_users" value="dm_by_role">
								<label for="dm_by_role">By role</label><br>
								<input class="aus_radio_option" type="radio" id="aud_radio_specific" name="dm_users" value="dm_direct">
								<label for="dm_direct">Specific user</label>
							</fieldset>
						</td>
					</tr>
					<tr>
						<th scope="row">Write Message</th>
						<td class="aud_admin_texarea">
							<form method="post" action="" enctype="multipart/form-data">
								<div id="aud_roles_wrap" class="aud_dm_opt show_dm_by_role" style="display: none;">
									<?php foreach($aud_roles as $key => $role) : ?>
									   <div class="aud_roles_checkbox">
									   		<input class="arc_single" type="checkbox" id="aud_arc_<?php echo $key;?>" name="aud_arc_opt" value="<?php echo $key;?>">
									   		<label for="aud_arc_<?php echo $key;?>"><?php echo $role;?></label>
									   	</div><br>
									<?php endforeach; ?>
								</div>
								<div id="aud_single_user" class="aud_dm_opt show_dm_direct" style="display: none; position: relative;">
									<?php 
									wp_dropdown_users(
										array('role__not_in'=> 'administrator', 'class' => 'aud-user-list')
									);
									?>
								</div><br>

								<textarea name="aud_admin_dm_message" rows="10" cols="50" id="aud_admin_dm_message" class="large-text code"></textarea>
								<div class="aud-admin-btn-wrap">
									<button class="abw-col button button-primary" id="aud-send-dm-btn">Send message</button>
									<img style="display: none;" class="abw-col aud-loader" src="<?php echo home_url('/wp-admin/images/loading.gif'); ?>" alt="default-loader">
									<div class="abw-col aud-status"></div>
								</div>
							<form>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	<?php }
	function aud_display_dm_page() {
		ob_start();
		$admin_dms= get_user_meta(get_current_user_id(), 'user_admin_dms', true); ?>
		<div class="aud-admin-dms-wrap">
			<?php if ($admin_dms) : ?>
				<?php foreach ($admin_dms as $key => $value):
		            $admin_dm = $value['admin_message'] ? : '';
					$dm_time = $value['time'] ? : '';
					$dm_id = $value['message_id'] ? : '';
					$dm_status = $value['status'] ? : '';
					?>
					<div class="adm-single dm-<?php echo $dm_id; ?>" dm-id="<?php echo $dm_id; ?>">
						<div class="adm-img adm-col"><img src="<?php echo esc_url( get_avatar_url( 1 ) ); ?>" alt="admin-img"></div>
						<div class="adm-content adm-col">
							<p class="adm-msg"><?php echo $admin_dm; ?></p>
							<div class="adm-actions <?php echo $dm_id; ?>-wrap" dm-id="<?php echo $dm_id; ?>">
								<?php if ($dm_status == 'unread') :?>
									<button class="adm-read adm-action" data="adm-read">Mark as read</button>
								<?php endif; ?>
									<button class="adm-delete adm-action" data="adm-delete">Delete</button>
									<img style="display: none;" class="abw-col aud-loader" src="<?php echo home_url('/wp-admin/images/loading.gif'); ?>" alt="default-loader">
									<p class="adm-time"><?php echo $dm_time; ?></p>
							</div>
						</div>
					</div>		
				<?php endforeach; ?>
			<?php else: ?>
				<p>No messages.</p>
			<?php endif; ?>
		</div>
	    <?php return ob_get_clean();
	}
	function aud_send_dm() {
		$aud_to = $_REQUEST['aud_to'] ? : '';
		$aud_dmn_message = $_REQUEST['aud_dmn_message'] ? : '';
		if($aud_to == 'dm_all_users') :
			$dm_users = get_users(array('role__not_in'=> 'administrator'));
			foreach ($dm_users as $key ) :
				$aud_user_id = $key->ID;
				send_dm($aud_user_id, $aud_dmn_message);
			endforeach;
		elseif ($aud_to == 'dm_by_role'):
			global $wp_roles;
			$aud_all_roles = $wp_roles->get_names();
			$aud_roles_array = array();
			$aud_roles = $_REQUEST['aud_roles'] ? : array();
			foreach ($aud_all_roles as $key => $role) {
				$aud_roles_array[] = $key;
			}
			foreach ($aud_roles as $key => $role) {
				if (in_array($role, $aud_roles_array)) :
					$users = get_users( array('role'=>$role));
					foreach ( $users as $user ) {
						$aud_user_id = $user->id;
						send_dm($aud_user_id,$aud_dmn_message);
					}
				endif;		
			}
		elseif ($aud_to == 'dm_direct'):
			$aud_user_id = $_REQUEST['aud_single_user'] ? : '';
			send_dm($aud_user_id,$aud_dmn_message);
		else:
			echo "Error! Please choose recipient.";
		endif;
		die();
	}
	function update_aud_message_title() {
		$posts = get_pages();
		$admin_dms= get_user_meta(get_current_user_id(), 'user_admin_dms', true) ? : array();
		$total_unread = '';
		$unread = array();
	    if( $admin_dms ) :
		    foreach( $admin_dms as $index => $admin_dm ):
		        if( $admin_dm['status'] == 'unread' ) :
		            $unread[] = $admin_dm['aud_user_id'];
		        endif;
		    endforeach;

		    if (count($unread)) :
				$total_unread = ' (' . count($unread) . ')';
		    endif;
		endif;
		
	    if ( empty($posts) ):
	        return $posts;
	 	endif;
	    // search through each post
	    foreach ($posts as $post) :
	        if ( stripos($post->post_content, 'aud-display-dm-page')) :
	            //Update post
				$new_title = preg_replace("/[^a-zA-Z]/", "", $post->post_title);
				$aud_post = array(
				    'ID'           => $post->ID,
				    'post_title'   => $new_title . $total_unread, // new title
				);
				wp_update_post( $aud_post );
	        endif;
	    endforeach;
	    return $posts;
	}
}
new ADMIN_USER_DM_CLASS;